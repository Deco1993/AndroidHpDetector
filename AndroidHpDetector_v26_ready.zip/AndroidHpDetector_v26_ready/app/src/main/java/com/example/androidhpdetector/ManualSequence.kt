package com.example.androidhpdetector

data class TapStep(val x: Float, val y: Float, val intervalAfterMs: Long = 500L)

/** Persistência da sequência manual. Cada passo possui seu próprio intervalo após o toque. */
object ManualSequenceStore {
    private const val PREFS = "manual_sequence"
    private const val STEPS = "steps"
    private const val REPEAT_COUNT = "repeat_count"

    fun load(context: android.content.Context): Pair<List<TapStep>, Int> {
        val prefs = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val raw = prefs.getString(STEPS, "") ?: ""
        val steps = raw.split(";").mapNotNull { item ->
            val parts = item.split(",")
            if (parts.size < 2) null else {
                val x = parts[0].toFloatOrNull()
                val y = parts[1].toFloatOrNull()
                val interval = parts.getOrNull(2)?.toLongOrNull() ?: 500L
                if (x != null && y != null && x >= 0f && y >= 0f) {
                    TapStep(x, y, interval.coerceIn(50L, 60_000L))
                } else null
            }
        }
        val repeat = prefs.getInt(REPEAT_COUNT, 1).coerceIn(1, 999)
        return steps to repeat
    }

    fun save(context: android.content.Context, steps: List<TapStep>, repeatCount: Int) {
        val encoded = steps.joinToString(";") {
            "${it.x},${it.y},${it.intervalAfterMs.coerceIn(50L, 60_000L)}"
        }
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit()
            .putString(STEPS, encoded)
            .putInt(REPEAT_COUNT, repeatCount.coerceIn(1, 999))
            .apply()
    }
}
