package com.example.androidhpdetector

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Detector visual temporal-friendly para uma região calibrada.
 * Combina conteúdo visual genérico com um perfil capturado durante a calibração.
 * Não executa nenhuma ação na tela.
 */
object TargetDetector {
    private data class Signature(
        val meanLuma: Float,
        val meanSaturation: Float,
        val foregroundRatio: Float,
        val colorRatio: Float,
        val edgeRatio: Float
    )

    fun analyze(bitmap: Bitmap?, region: TargetRegion?, profile: TargetProfile? = null): TargetDetection {
        if (bitmap == null || region == null || bitmap.width <= 1 || bitmap.height <= 1) {
            return TargetDetection(false, 0, 0f, 0f)
        }

        val signature = signature(bitmap, region) ?: return TargetDetection(false, 0, 0f, 0f)
        val generic = (signature.foregroundRatio * 0.38f +
                signature.colorRatio * 0.32f +
                signature.edgeRatio * 0.30f).coerceIn(0f, 1f)

        val similarity = profile?.let { compare(signature, it) } ?: 0f
        val score = if (profile != null) {
            generic * 0.55f + similarity * 0.45f
        } else {
            generic
        }

        val confidence = (score * 100f).toInt().coerceIn(0, 100)
        val detected = if (profile != null) {
            confidence >= 55 && signature.foregroundRatio >= 0.04f && similarity >= 0.45f
        } else {
            confidence >= 45 && signature.foregroundRatio >= 0.06f
        }

        return TargetDetection(
            detected = detected,
            confidence = confidence,
            foregroundRatio = signature.foregroundRatio,
            colorRatio = signature.colorRatio,
            profileSimilarity = similarity
        )
    }

    fun createProfile(bitmap: Bitmap?, region: TargetRegion?): TargetProfile? {
        val s = if (bitmap != null && region != null) signature(bitmap, region) else null
        return s?.let { TargetProfile(it.meanLuma, it.meanSaturation, it.foregroundRatio, it.colorRatio, it.edgeRatio) }
    }

    private fun signature(bitmap: Bitmap, region: TargetRegion): Signature? {
        val left = region.left.coerceIn(0, bitmap.width - 1)
        val top = region.top.coerceIn(0, bitmap.height - 1)
        val right = region.right.coerceIn(left + 1, bitmap.width)
        val bottom = region.bottom.coerceIn(top + 1, bitmap.height)
        val stepX = max(1, (right - left) / 80)
        val stepY = max(1, (bottom - top) / 24)

        var sampled = 0
        var foreground = 0
        var colored = 0
        var edgeHits = 0
        var lumaSum = 0f
        var satSum = 0f
        var previousLuma = -1f

        for (y in top until bottom step stepY) {
            for (x in left until right step stepX) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16 and 0xFF) / 255f
                val g = (c shr 8 and 0xFF) / 255f
                val b = (c and 0xFF) / 255f
                val maxC = max(r, max(g, b))
                val minC = minOf(r, g, b)
                val luma = 0.2126f * r + 0.7152f * g + 0.0722f * b
                val saturation = if (maxC <= 0.01f) 0f else (maxC - minC) / maxC
                sampled++
                lumaSum += luma
                satSum += saturation
                if (luma > 0.38f || saturation > 0.42f) foreground++
                if (saturation > 0.35f && maxC > 0.35f) colored++
                if (previousLuma >= 0f && abs(luma - previousLuma) > 0.16f) edgeHits++
                previousLuma = luma
            }
        }

        if (sampled == 0) return null
        return Signature(
            meanLuma = lumaSum / sampled,
            meanSaturation = satSum / sampled,
            foregroundRatio = foreground.toFloat() / sampled,
            colorRatio = colored.toFloat() / sampled,
            edgeRatio = (edgeHits.toFloat() / sampled).coerceIn(0f, 1f)
        )
    }

    private fun compare(s: Signature, p: TargetProfile): Float {
        fun closeness(a: Float, b: Float, scale: Float): Float =
            (1f - abs(a - b) / scale).coerceIn(0f, 1f)

        val luma = closeness(s.meanLuma, p.meanLuma, 0.45f)
        val sat = closeness(s.meanSaturation, p.meanSaturation, 0.55f)
        val fg = closeness(s.foregroundRatio, p.foregroundRatio, 0.45f)
        val color = closeness(s.colorRatio, p.colorRatio, 0.45f)
        val edge = closeness(s.edgeRatio, p.edgeRatio, 0.35f)
        return sqrt((luma*luma*0.15f + sat*sat*0.15f + fg*fg*0.25f + color*color*0.25f + edge*edge*0.20f).coerceIn(0f, 1f))
    }
}
