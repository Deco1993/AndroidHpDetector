package com.example.androidhpdetector

import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var hpLimit: EditText
    private lateinit var hpRecoveryMargin: EditText
    private lateinit var hpRecoveryConfirmFrames: EditText
    private lateinit var confidence: EditText
    private lateinit var confirmFrames: EditText
    private lateinit var missingFrames: EditText
    private val cooldownFields = mutableMapOf<AutomationState, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val config = ConfigStore.load(this)

        fun numberField(label: String, value: Int): EditText = EditText(this).apply {
            hint = label
            setText(value.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 17f
        }

        val title = TextView(this).apply {
            text = "Configurações da automação"
            textSize = 24f
            setPadding(0, 0, 0, 20)
        }

        val description = TextView(this).apply {
            text = "Esses parâmetros controlam apenas a decisão da máquina de estados. Nenhum clique ou ataque é executado por esta configuração."
            textSize = 15f
            setPadding(0, 0, 0, 20)
        }

        hpLimit = numberField("Limite de HP (%)", config.hpLimit)
        hpRecoveryMargin = numberField("Margem de recuperação de HP (%)", config.hpRecoveryMargin)
        hpRecoveryConfirmFrames = numberField("Frames consecutivos para confirmar recuperação", config.hpRecoveryConfirmFrames)
        confidence = numberField("Confiança mínima do alvo (%)", config.targetConfidenceLimit)
        confirmFrames = numberField("Frames para confirmar alvo", config.targetConfirmFrames)
        missingFrames = numberField("Frames para considerar alvo perdido", config.targetMissingFrames)

        val cooldownTitle = TextView(this).apply {
            text = "Cooldown por estado (ms)"
            textSize = 18f
            setPadding(0, 24, 0, 8)
        }
        val cooldownContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(AutomationState.CHECK_HP, AutomationState.SEARCH_TARGET, AutomationState.TARGET_FOUND, AutomationState.ATTACKING, AutomationState.CHECK_DEATH, AutomationState.LOOTING).forEach { state ->
            val field = numberField(state.name, CooldownConfigStore.load(this, state).toInt())
            cooldownFields[state] = field
            cooldownContainer.addView(field)
        }

        val help = TextView(this).apply {
            text = "Sugestão inicial:\nHP 25% • recuperação +5% (libera em 30%) • 3 frames consecutivos para confirmar recuperação • confiança 55% • 3 frames para confirmar alvo • 4 frames para perder.\n\nAumentar a confiança reduz falsos positivos, mas pode dificultar a detecção. Aumentar os frames deixa a máquina mais estável, porém mais lenta para reagir."
            textSize = 14f
            setPadding(0, 12, 0, 20)
        }

        val save = Button(this).apply {
            text = "Salvar configurações"
            setOnClickListener { saveConfig() }
        }

        val defaults = Button(this).apply {
            text = "Restaurar padrões"
            setOnClickListener {
                hpLimit.setText("25")
                hpRecoveryMargin.setText("5")
                hpRecoveryConfirmFrames.setText("3")
                confidence.setText("55")
                confirmFrames.setText("3")
                missingFrames.setText("4")
                CooldownConfigStore.defaults().forEach { (state, value) -> cooldownFields[state]?.setText(value.toString()) }
            }
        }

        val close = Button(this).apply {
            text = "Voltar"
            setOnClickListener { finish() }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            addView(title)
            addView(description)
            addView(hpLimit)
            addView(hpRecoveryMargin)
            addView(hpRecoveryConfirmFrames)
            addView(confidence)
            addView(confirmFrames)
            addView(missingFrames)
            addView(cooldownTitle)
            addView(cooldownContainer)
            addView(help)
            addView(save)
            addView(defaults)
            addView(close)
        }

        setContentView(ScrollView(this).apply { addView(content) })
    }

    private fun EditText.valueAsIntOrNull(): Int? = text.toString().toIntOrNull()

    private fun saveConfig() {
        val hp = hpLimit.text.toString().toIntOrNull()
        val recoveryMargin = hpRecoveryMargin.text.toString().toIntOrNull()
        val recoveryConfirm = hpRecoveryConfirmFrames.text.toString().toIntOrNull()
        val confidenceValue = confidence.text.toString().toIntOrNull()
        val confirm = confirmFrames.text.toString().toIntOrNull()
        val missing = missingFrames.text.toString().toIntOrNull()

        if (hp == null || hp !in 1..100 ||
            recoveryMargin == null || recoveryMargin !in 0..50 ||
            recoveryConfirm == null || recoveryConfirm !in 1..30 ||
            confidenceValue == null || confidenceValue !in 1..100 ||
            confirm == null || confirm !in 1..30 ||
            missing == null || missing !in 1..30
        ) {
            Toast.makeText(this, "Confira os valores informados.", Toast.LENGTH_SHORT).show()
            return
        }

        val cooldowns = cooldownFields.mapValues { (_, field) -> field.valueAsIntOrNull() ?: -1 }.mapValues { it.value.toLong() }
        if (cooldowns.values.any { it !in 0L..60_000L }) {
            Toast.makeText(this, "Cooldowns devem ficar entre 0 e 60000 ms.", Toast.LENGTH_SHORT).show()
            return
        }
        ConfigStore.save(this, AppConfig(hp, recoveryMargin, recoveryConfirm, confidenceValue, confirm, missing))
        CooldownConfigStore.save(this, cooldowns)
        Toast.makeText(this, "Configurações salvas.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
