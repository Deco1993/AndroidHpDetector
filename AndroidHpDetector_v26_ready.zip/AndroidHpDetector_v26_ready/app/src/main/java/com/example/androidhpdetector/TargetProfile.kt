package com.example.androidhpdetector

data class TargetProfile(
    val meanLuma: Float,
    val meanSaturation: Float,
    val foregroundRatio: Float,
    val colorRatio: Float,
    val edgeRatio: Float
)
