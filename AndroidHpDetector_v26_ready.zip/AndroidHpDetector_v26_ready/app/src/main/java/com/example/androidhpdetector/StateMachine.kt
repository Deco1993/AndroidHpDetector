package com.example.androidhpdetector

/** Máquina de decisão. Não executa cliques nem ações no jogo. */
class StateMachine(private val actionExecutor: ActionExecutor = DiagnosticActionExecutor()) {
    var state: AutomationState = AutomationState.IDLE
        private set

    var hpLimit = 25
    var targetConfidenceLimit = 55
    var requiredTargetFrames = 3
    var requiredMissingFrames = 4

    private var targetPositiveFrames = 0
    private var targetMissingFrames = 0
    private var lastTransition: String = "Inicializado"
    private val transitionHistory = ArrayDeque<String>()
    private var transitionVersion = 0L

    fun transitionDescription(): String = lastTransition
    fun positiveFrames(): Int = targetPositiveFrames
    fun missingFrames(): Int = targetMissingFrames
    fun history(): List<String> = transitionHistory.toList()
    fun transitionVersion(): Long = transitionVersion

    fun start() {
        resetCounters()
        changeTo(AutomationState.CHECK_HP, "Máquina iniciada")
    }

    /** Força o retorno imediato ao estado de segurança de HP. */
    fun emergencyHpCheck(hp: Int) {
        resetCounters()
        changeTo(AutomationState.CHECK_HP, "Interrupção de segurança: HP abaixo do limite (${hp}%)")
    }

    /** Após recuperação confirmada, libera o fluxo normal começando pela busca de alvo. */
    fun resumeAfterHpRecovery() {
        resetCounters()
        changeTo(AutomationState.SEARCH_TARGET, "Recuperação de HP confirmada; retomando busca de alvo")
    }

    fun stop() {
        resetCounters()
        changeTo(AutomationState.IDLE, "Máquina parada")
    }

    fun pause() {
        if (state != AutomationState.IDLE) changeTo(AutomationState.PAUSED, "Pausado pelo usuário")
    }

    fun resume() {
        if (state == AutomationState.PAUSED) {
            resetCounters()
            changeTo(AutomationState.CHECK_HP, "Retomado")
        }
    }

    fun tick(hp: Int?, target: TargetDetection): AutomationState {
        if (state == AutomationState.IDLE || state == AutomationState.PAUSED) return state

        val validTarget = target.detected && target.confidence >= targetConfidenceLimit
        if (validTarget) {
            targetPositiveFrames++
            targetMissingFrames = 0
        } else {
            targetMissingFrames++
            targetPositiveFrames = 0
        }

        when (state) {
            AutomationState.CHECK_HP -> {
                if (hp == null) return state
                if (hp <= hpLimit) {
                    changeTo(AutomationState.CHECK_HP, "HP abaixo do limite (${hp}%)")
                } else {
                    changeTo(AutomationState.SEARCH_TARGET, "HP seguro (${hp}%)")
                }
            }
            AutomationState.SEARCH_TARGET -> {
                if (hp != null && hp <= hpLimit) {
                    changeTo(AutomationState.CHECK_HP, "HP baixo durante busca (${hp}%)")
                } else if (targetPositiveFrames >= requiredTargetFrames) {
                    changeTo(AutomationState.TARGET_FOUND, "Alvo confirmado por ${targetPositiveFrames} frames")
                }
            }
            AutomationState.TARGET_FOUND -> {
                changeTo(AutomationState.ATTACKING, "Alvo confirmado; pronto para combate")
            }
            AutomationState.ATTACKING -> {
                if (hp != null && hp <= hpLimit) {
                    changeTo(AutomationState.CHECK_HP, "HP baixo durante combate (${hp}%)")
                } else if (targetMissingFrames >= requiredMissingFrames) {
                    changeTo(AutomationState.CHECK_DEATH, "Alvo ausente por ${targetMissingFrames} frames")
                }
            }
            AutomationState.CHECK_DEATH -> {
                if (validTarget) {
                    changeTo(AutomationState.ATTACKING, "Alvo reapareceu; morte não confirmada")
                } else if (targetMissingFrames >= requiredMissingFrames) {
                    changeTo(AutomationState.LOOTING, "Ausência sustentada; morte provável")
                }
            }
            AutomationState.LOOTING -> {
                changeTo(AutomationState.SEARCH_TARGET, "Janela de loot concluída (sem ação executada)")
            }
            AutomationState.IDLE, AutomationState.PAUSED -> Unit
        }
        actionExecutor.onStateTick(state)
        return state
    }

    fun lastAction(): String = (actionExecutor as? DiagnosticActionExecutor)?.lastAction ?: "Executor ativo"

    fun actionCount(): Long = (actionExecutor as? DiagnosticActionExecutor)?.actionCount ?: 0L

    private fun changeTo(next: AutomationState, reason: String) {
        val changed = state != next
        if (changed || reason != lastTransition) {
            state = next
            lastTransition = reason
            if (changed) {
                transitionVersion++
                actionExecutor.onStateEntered(next, reason)
                transitionHistory.addFirst("${next.name}: $reason")
                while (transitionHistory.size > 8) transitionHistory.removeLast()
            }
        }
    }

    private fun resetCounters() {
        targetPositiveFrames = 0
        targetMissingFrames = 0
    }
}
