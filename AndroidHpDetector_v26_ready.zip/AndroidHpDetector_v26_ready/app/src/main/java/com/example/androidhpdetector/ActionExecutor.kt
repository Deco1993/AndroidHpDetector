package com.example.androidhpdetector

/**
 * Camada de ações desacoplada da máquina de estados.
 * Nesta etapa o executor é somente diagnóstico (dry-run): não envia toques ao jogo.
 */
interface ActionExecutor {
    fun onStateEntered(state: AutomationState, reason: String)
    fun onStateTick(state: AutomationState)
    fun clear()
}

class DiagnosticActionExecutor : ActionExecutor {
    @Volatile var lastAction: String = "Nenhuma ação"
        private set

    @Volatile var actionCount: Long = 0
        private set

    override fun onStateEntered(state: AutomationState, reason: String) {
        lastAction = when (state) {
            AutomationState.CHECK_HP -> "CHECK_HP: verificar HP"
            AutomationState.SEARCH_TARGET -> "SEARCH_TARGET: procurar alvo"
            AutomationState.TARGET_FOUND -> "TARGET_FOUND: alvo confirmado"
            AutomationState.ATTACKING -> "ATTACKING: pronto para ação de combate (dry-run)"
            AutomationState.CHECK_DEATH -> "CHECK_DEATH: verificar morte"
            AutomationState.LOOTING -> "LOOTING: pronto para coleta (dry-run)"
            AutomationState.PAUSED -> "PAUSED: ações suspensas"
            AutomationState.IDLE -> "IDLE: executor parado"
        }
        actionCount++
    }

    override fun onStateTick(state: AutomationState) = Unit

    override fun clear() {
        lastAction = "Nenhuma ação"
        actionCount = 0
    }
}
