package com.example.androidhpdetector

import android.content.Context

object StateProfileMappingStore {
    private const val PREFS = "state_profile_mapping"
    private const val PREFIX = "state_"

    fun set(context: Context, state: AutomationState, profileName: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
            if (profileName.isNullOrBlank()) remove(PREFIX + state.name)
            else putString(PREFIX + state.name, profileName)
        }.apply()
    }

    fun get(context: Context, state: AutomationState): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREFIX + state.name, null)

    fun all(context: Context): Map<AutomationState, String> =
        AutomationState.values().associateWith { get(context, it) }.filterValues { !it.isNullOrBlank() }
}
