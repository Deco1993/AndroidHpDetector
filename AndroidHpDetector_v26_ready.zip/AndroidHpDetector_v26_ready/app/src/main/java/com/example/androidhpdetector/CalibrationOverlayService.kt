package com.example.androidhpdetector

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class CalibrationOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: CalibrationOverlayView? = null
    private var calibrationTarget = CalibrationTarget.HP

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        calibrationTarget = if (intent?.getStringExtra(EXTRA_TARGET) == "target") CalibrationTarget.TARGET else CalibrationTarget.HP
        if (overlayView == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            overlayView = CalibrationOverlayView(this, calibrationTarget) { action ->
                when (action) {
                    Action.SAVE -> saveAndClose()
                    Action.CANCEL -> stopSelf()
                }
            }

            val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
            }

            try {
                windowManager.addView(overlayView, params)
            } catch (_: Exception) {
                Toast.makeText(this, "Não foi possível abrir a calibração sobre o jogo.", Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun saveAndClose() {
        val frame = CaptureState.lastPreviewFrame
        val view = overlayView ?: return
        if (frame == null) {
            Toast.makeText(this, "Nenhum frame de captura disponível.", Toast.LENGTH_SHORT).show()
            return
        }

        val normalized = view.selection
        val region = HpRegion(
            left = (normalized.left * frame.width).toInt().coerceIn(0, frame.width - 1),
            top = (normalized.top * frame.height).toInt().coerceIn(0, frame.height - 1),
            right = (normalized.right * frame.width).toInt().coerceIn(1, frame.width),
            bottom = (normalized.bottom * frame.height).toInt().coerceIn(1, frame.height)
        )

        if (calibrationTarget == CalibrationTarget.HP) {
            CaptureState.hpRegion = region
            Toast.makeText(this, "Região de HP salva.", Toast.LENGTH_SHORT).show()
        } else {
            CaptureState.targetRegion = TargetRegion(region.left, region.top, region.right, region.bottom)
            CaptureState.targetProfile = TargetDetector.createProfile(frame, CaptureState.targetRegion)
            Toast.makeText(this, "Região e perfil do alvo salvos.", Toast.LENGTH_SHORT).show()
        }
        stopSelf()
    }

    override fun onDestroy() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) { }
        }
        overlayView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private enum class Action { SAVE, CANCEL }
    private enum class CalibrationTarget { HP, TARGET }

    private class CalibrationOverlayView(
        context: Context,
        private val target: CalibrationTarget,
        private val onAction: (Action) -> Unit
    ) : View(context) {

        val selection = RectF(0.20f, 0.08f, 0.80f, 0.15f)

        private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = 90 }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 42f
            isFakeBoldText = true
        }
        private val buttonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = 210 }
        private val buttonTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 34f
            isFakeBoldText = true
        }

        private enum class Mode { NONE, MOVE, LEFT, RIGHT, TOP, BOTTOM }
        private var mode = Mode.NONE
        private var lastX = 0f
        private var lastY = 0f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val r = rectPx()
            val save = RectF(width - 300f, 30f, width - 30f, 110f)
            val cancel = RectF(30f, 30f, 300f, 110f)

            canvas.drawRect(0f, 0f, width.toFloat(), r.top, dimPaint)
            canvas.drawRect(0f, r.bottom, width.toFloat(), height.toFloat(), dimPaint)
            canvas.drawRect(0f, r.top, r.left, r.bottom, dimPaint)
            canvas.drawRect(r.right, r.top, width.toFloat(), r.bottom, dimPaint)
            canvas.drawRect(r, borderPaint)

            canvas.drawText(if (target == CalibrationTarget.HP) "Ajuste sobre a barra de HP" else "Ajuste sobre o nome/indicador do alvo", 30f, 165f, textPaint)

            canvas.drawRoundRect(cancel, 16f, 16f, buttonPaint)
            canvas.drawRoundRect(save, 16f, 16f, buttonPaint)
            canvas.drawText("Cancelar", 65f, 82f, buttonTextPaint)
            canvas.drawText("SALVAR", width - 255f, 82f, buttonTextPaint)
        }

        private fun rectPx(): RectF = RectF(
            selection.left * width,
            selection.top * height,
            selection.right * width,
            selection.bottom * height
        )

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val save = RectF(width - 300f, 30f, width - 30f, 110f)
            val cancel = RectF(30f, 30f, 300f, 110f)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (save.contains(event.x, event.y)) {
                        onAction(Action.SAVE)
                        return true
                    }
                    if (cancel.contains(event.x, event.y)) {
                        onAction(Action.CANCEL)
                        return true
                    }

                    lastX = event.x
                    lastY = event.y
                    val r = rectPx()
                    val edge = 45f
                    mode = when {
                        event.x in r.left - edge..r.left + edge && event.y in r.top..r.bottom -> Mode.LEFT
                        event.x in r.right - edge..r.right + edge && event.y in r.top..r.bottom -> Mode.RIGHT
                        event.y in r.top - edge..r.top + edge && event.x in r.left..r.right -> Mode.TOP
                        event.y in r.bottom - edge..r.bottom + edge && event.x in r.left..r.right -> Mode.BOTTOM
                        r.contains(event.x, event.y) -> Mode.MOVE
                        else -> Mode.NONE
                    }
                    return true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = if (width == 0) 0f else (event.x - lastX) / width
                    val dy = if (height == 0) 0f else (event.y - lastY) / height

                    when (mode) {
                        Mode.MOVE -> {
                            val w = selection.width()
                            val h = selection.height()
                            selection.offset(dx, dy)
                            if (selection.left < 0f) selection.offset(-selection.left, 0f)
                            if (selection.top < 0f) selection.offset(0f, -selection.top)
                            if (selection.right > 1f) selection.offset(1f - selection.right, 0f)
                            if (selection.bottom > 1f) selection.offset(0f, 1f - selection.bottom)
                            selection.set(selection.left, selection.top, selection.left + w, selection.top + h)
                        }
                        Mode.LEFT -> selection.left = min(selection.right - 0.01f, max(0f, selection.left + dx))
                        Mode.RIGHT -> selection.right = max(selection.left + 0.01f, min(1f, selection.right + dx))
                        Mode.TOP -> selection.top = min(selection.bottom - 0.01f, max(0f, selection.top + dy))
                        Mode.BOTTOM -> selection.bottom = max(selection.top + 0.01f, min(1f, selection.bottom + dy))
                        Mode.NONE -> Unit
                    }

                    lastX = event.x
                    lastY = event.y
                    invalidate()
                    return true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mode = Mode.NONE
                    return true
                }
            }
            return true
        }
    }

    companion object {
        const val EXTRA_TARGET = "calibration_target"

        fun start(context: Context, target: Boolean = false) {
            val intent = Intent(context, CalibrationOverlayService::class.java)
                .putExtra(EXTRA_TARGET, if (target) "target" else "hp")
            context.startService(intent)
        }
    }
}
