package com.example.androidhpdetector

import android.content.Context
import android.util.Base64

data class SequenceProfile(val name: String, val steps: List<TapStep>, val repeatCount: Int)

object SequenceProfileStore {
    private const val PREFS = "sequence_profiles"
    private const val NAMES = "names"
    private const val PREFIX = "profile_"

    private fun key(name: String): String = PREFIX + Base64.encodeToString(name.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

    fun list(context: Context): List<String> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getStringSet(NAMES, emptySet())!!.toList().sorted(String.CASE_INSENSITIVE_ORDER)

    fun save(context: Context, profile: SequenceProfile) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val names = prefs.getStringSet(NAMES, emptySet())!!.toMutableSet()
        names.add(profile.name)
        val encoded = profile.steps.joinToString(";") { "${it.x},${it.y},${it.intervalAfterMs}" }
        prefs.edit().putStringSet(NAMES, names).putString(key(profile.name), "$encoded|${profile.repeatCount.coerceIn(1, 999)}").apply()
    }

    fun load(context: Context, name: String): SequenceProfile? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(key(name), null) ?: return null
        val split = raw.lastIndexOf('|')
        val encodedSteps = if (split >= 0) raw.substring(0, split) else raw
        val repeat = if (split >= 0) raw.substring(split + 1).toIntOrNull() ?: 1 else 1
        val steps = encodedSteps.split(';').filter { it.isNotBlank() }.mapNotNull { item ->
            val p = item.split(',')
            if (p.size < 2) return@mapNotNull null
            val x = p[0].toFloatOrNull() ?: return@mapNotNull null
            val y = p[1].toFloatOrNull() ?: return@mapNotNull null
            val interval = p.getOrNull(2)?.toLongOrNull() ?: 500L
            if (x >= 0 && y >= 0) TapStep(x, y, interval.coerceIn(50L, 60_000L)) else null
        }
        return SequenceProfile(name, steps, repeat.coerceIn(1, 999))
    }

    fun delete(context: Context, name: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val names = prefs.getStringSet(NAMES, emptySet())!!.toMutableSet()
        names.remove(name)
        prefs.edit().putStringSet(NAMES, names).remove(key(name)).apply()
    }
}
