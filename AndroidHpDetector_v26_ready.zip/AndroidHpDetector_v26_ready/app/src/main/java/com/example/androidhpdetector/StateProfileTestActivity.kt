package com.example.androidhpdetector

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class StateProfileTestActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var currentIndex = 0
    private var currentRound = 1
    private var profile: SequenceProfile? = null
    private lateinit var stateSpinner: Spinner
    private lateinit var profileText: TextView
    private lateinit var sequenceText: TextView
    private lateinit var statusText: TextView
    private lateinit var runButton: Button

    private val states = listOf(
        AutomationState.CHECK_HP,
        AutomationState.SEARCH_TARGET,
        AutomationState.TARGET_FOUND,
        AutomationState.ATTACKING,
        AutomationState.CHECK_DEATH,
        AutomationState.LOOTING
    )

    private val runner = object : Runnable {
        override fun run() {
            if (!running) return
            val p = profile ?: return stopRun("Nenhum perfil carregado.")
            if (currentIndex !in p.steps.indices) return stopRun("Execução concluída.")
            val step = p.steps[currentIndex]
            val ok = AutomationAccessibilityService.tap(step.x, step.y)
            statusText.text = "${if (ok) "Toque enviado" else "Falha ao enviar toque"} • rodada $currentRound/${p.repeatCount} • passo ${currentIndex + 1}/${p.steps.size}"
            currentIndex++
            if (currentIndex >= p.steps.size) {
                if (currentRound >= p.repeatCount) return stopRun("Perfil executado com sucesso.")
                currentRound++
                currentIndex = 0
            }
            handler.postDelayed(this, step.intervalAfterMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 28) }
        root.addView(TextView(this).apply { text = "Teste manual por estado"; textSize = 24f })
        root.addView(TextView(this).apply {
            text = "Selecione um estado. O perfil associado será mostrado antes da execução. A execução só começa após confirmação."
            textSize = 15f; setPadding(0, 12, 0, 18)
        })
        stateSpinner = Spinner(this)
        stateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, states.map { it.name })
        root.addView(stateSpinner)

        profileText = TextView(this).apply { textSize = 17f; setPadding(0, 18, 0, 10) }
        sequenceText = TextView(this).apply { textSize = 15f; setPadding(0, 4, 0, 18) }
        statusText = TextView(this).apply { text = "Selecione um estado."; textSize = 15f; setPadding(0, 8, 0, 16) }
        root.addView(profileText); root.addView(sequenceText); root.addView(statusText)

        stateSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { loadSelected() }
        }

        val refresh = Button(this).apply { text = "Atualizar perfil"; setOnClickListener { loadSelected() } }
        runButton = Button(this).apply { text = "Executar perfil manualmente"; setOnClickListener { confirmAndRun() } }
        val stop = Button(this).apply { text = "Parar"; setOnClickListener { stopRun("Execução interrompida.") } }
        val back = Button(this).apply { text = "Voltar"; setOnClickListener { finish() } }
        root.addView(refresh); root.addView(runButton); root.addView(stop); root.addView(back)
        setContentView(ScrollView(this).apply { addView(root) })
        loadSelected()
    }

    private fun selectedState(): AutomationState = states[stateSpinner.selectedItemPosition.coerceIn(states.indices)]

    private fun loadSelected() {
        if (!::stateSpinner.isInitialized) return
        val state = selectedState()
        val name = StateProfileMappingStore.get(this, state)
        profile = name?.let { SequenceProfileStore.load(this, it) }
        if (profile == null) {
            profileText.text = "Perfil associado: nenhum"
            sequenceText.text = "Nenhuma sequência disponível para ${state.name}."
            runButton.isEnabled = false
            return
        }
        val p = profile!!
        profileText.text = "Estado: ${state.name}\nPerfil associado: ${p.name}\nRepetições: ${p.repeatCount}"
        sequenceText.text = p.steps.mapIndexed { i, s ->
            "${i + 1}. X=${s.x}  Y=${s.y}  → ${s.intervalAfterMs} ms"
        }.joinToString("\n").ifBlank { "Perfil sem pontos." }
        runButton.isEnabled = p.steps.isNotEmpty()
        statusText.text = "Perfil carregado. Revise a sequência antes de executar."
    }

    private fun confirmAndRun() {
        val p = profile ?: return
        if (!AutomationAccessibilityService.isConnected()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            statusText.text = "Ative o serviço de acessibilidade e volte para executar."
            return
        }
        val preview = p.steps.mapIndexed { i, s -> "${i + 1}. (${s.x}, ${s.y}) — ${s.intervalAfterMs} ms" }.joinToString("\n")
        AlertDialog.Builder(this)
            .setTitle("Confirmar execução")
            .setMessage("Perfil: ${p.name}\nRepetições: ${p.repeatCount}\n\n$preview")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Iniciar") { _, _ -> startRun() }
            .show()
    }

    private fun startRun() {
        val p = profile ?: return
        running = true; currentIndex = 0; currentRound = 1
        runButton.text = "Executando…"; runButton.isEnabled = false
        statusText.text = "Execução iniciada: ${p.name}."
        handler.removeCallbacks(runner); handler.post(runner)
    }

    private fun stopRun(message: String) {
        running = false; handler.removeCallbacks(runner)
        runButton.text = "Executar perfil manualmente"; runButton.isEnabled = profile?.steps?.isNotEmpty() == true
        statusText.text = message
    }

    override fun onDestroy() { stopRun("Execução encerrada."); super.onDestroy() }
}
