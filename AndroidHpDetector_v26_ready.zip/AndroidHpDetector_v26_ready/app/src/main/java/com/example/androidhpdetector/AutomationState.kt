package com.example.androidhpdetector

enum class AutomationState {
    IDLE,
    CHECK_HP,
    SEARCH_TARGET,
    TARGET_FOUND,
    ATTACKING,
    CHECK_DEATH,
    LOOTING,
    PAUSED
}
