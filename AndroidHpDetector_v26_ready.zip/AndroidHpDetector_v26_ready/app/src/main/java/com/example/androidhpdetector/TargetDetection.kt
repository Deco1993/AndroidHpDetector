package com.example.androidhpdetector

data class TargetDetection(
    val detected: Boolean,
    val confidence: Int,
    val foregroundRatio: Float,
    val colorRatio: Float,
    val profileSimilarity: Float = 0f
)
