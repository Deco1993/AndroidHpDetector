package com.example.androidhpdetector

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.app.AlertDialog
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var hpText: TextView
    private lateinit var targetText: TextView
    private lateinit var stateText: TextView
    private lateinit var transitionText: TextView
    private lateinit var framesText: TextView
    private lateinit var historyText: TextView
    private lateinit var actionText: TextView
    private lateinit var profileText: TextView
    private lateinit var mediaProjectionManager: MediaProjectionManager

    private val uiHandler = Handler(Looper.getMainLooper())
    private var displayedHp = 0
    private val stateMachine = StateMachine()
    // Configurações persistidas; os valores salvos são recarregados também no onResume.
    private var config = AppConfig()
    private var automaticMode = false
    private var lastHandledTransitionVersion = -1L
    private lateinit var automaticRunner: AutomaticProfileRunner
    private var automaticStatusText: TextView? = null

    private val uiUpdater = object : Runnable {
        override fun run() {
            updateUi()
            uiHandler.postDelayed(this, 200L)
        }
    }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
                status.text = "Captura iniciada. Calibre HP e alvo."
            } else {
                status.text = "Permissão de captura recusada."
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mediaProjectionManager = getSystemService(MediaProjectionManager::class.java)
        automaticRunner = AutomaticProfileRunner { message -> status.text = message }
        applyConfig()

        hpText = TextView(this).apply {
            text = "HP: --%"
            textSize = 30f
            setPadding(32, 32, 32, 8)
        }
        targetText = TextView(this).apply {
            text = "Alvo: --"
            textSize = 21f
            setPadding(32, 8, 32, 8)
        }
        stateText = TextView(this).apply {
            text = "Estado: IDLE"
            textSize = 21f
            setPadding(32, 8, 32, 8)
        }
        transitionText = TextView(this).apply {
            text = "Motivo: Inicializado"
            textSize = 16f
            setPadding(32, 4, 32, 8)
        }
        framesText = TextView(this).apply {
            text = "Frames positivos: 0 | ausentes: 0"
            textSize = 15f
            setPadding(32, 4, 32, 8)
        }
        historyText = TextView(this).apply {
            text = "Histórico de transições:\n—"
            textSize = 14f
            setPadding(32, 4, 32, 16)
        }
        profileText = TextView(this).apply {
            text = "Perfil sugerido: nenhum"
            textSize = 15f
            setPadding(32, 4, 32, 8)
        }
        actionText = TextView(this).apply {
            text = "Ação: Nenhuma ação"
            textSize = 15f
            setPadding(32, 4, 32, 16)
        }

        status = TextView(this).apply {
            text = "Pronto."
            textSize = 17f
            setPadding(32, 8, 32, 24)
        }

        val startButton = Button(this).apply {
            text = "Iniciar captura"
            setOnClickListener { requestCapture() }
        }

        val hpCalibrationButton = Button(this).apply {
            text = "Calibrar barra de HP"
            setOnClickListener { startCalibration(false) }
        }

        val targetCalibrationButton = Button(this).apply {
            text = "Calibrar detector de alvo"
            setOnClickListener { startCalibration(true) }
        }

        val settingsButton = Button(this).apply {
            text = "Configurar parâmetros"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }

        val testTapButton = Button(this).apply {
            text = "Testar toque manual"
            setOnClickListener { showManualTapDialog() }
        }

        val mappingButton = Button(this).apply {
            text = "Perfis por estado (modo assistido)"
            setOnClickListener { startActivity(Intent(this@MainActivity, StateProfileMappingActivity::class.java)) }
        }

        val stateTestButton = Button(this).apply {
            text = "Testar perfil por estado (manual)"
            setOnClickListener { startActivity(Intent(this@MainActivity, StateProfileTestActivity::class.java)) }
        }

        val sequenceButton = Button(this).apply {
            text = "Sequência manual de toques"
            setOnClickListener { startActivity(Intent(this@MainActivity, ManualSequenceActivity::class.java)) }
        }

        val startLogicButton = Button(this).apply {
            text = "Iniciar máquina de estados"
            setOnClickListener {
                stateMachine.start()
                status.text = "Máquina de estados iniciada. Nenhuma ação de combate é executada."
            }
        }

        automaticStatusText = TextView(this).apply {
            text = "Automático: AGUARDANDO"
            textSize = 15f
            setPadding(0, 8, 0, 8)
        }

        val automaticButton = Button(this).apply {
            text = "Modo automático: DESLIGADO"
            setOnClickListener {
                if (automaticMode) {
                    automaticMode = false
                    automaticRunner.stop("Modo automático desligado.")
                    text = "Modo automático: DESLIGADO"
                    status.text = "Modo automático desligado."
                } else {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Ativar modo automático?")
                        .setMessage("Os perfis associados aos estados poderão executar toques automaticamente. Ative somente depois de conferir as coordenadas e perfis. Não há mecanismos de evasão de anti-cheat.")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Ativar") { _, _ ->
                            if (!AutomationAccessibilityService.isConnected()) {
                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                status.text = "Ative a acessibilidade antes de ativar o modo automático."
                                return@setPositiveButton
                            }
                            automaticMode = true
                            lastHandledTransitionVersion = stateMachine.transitionVersion()
                            text = "Modo automático: LIGADO"
                            status.text = "Modo automático ligado. As transições poderão executar perfis associados."
                        }
                        .show()
                }
            }
        }

        val pauseButton = Button(this).apply {
            text = "Pausar lógica"
            setOnClickListener {
                stateMachine.pause()
                status.text = "Lógica pausada."
            }
        }

        val stopButton = Button(this).apply {
            text = "Parar captura e lógica"
            setOnClickListener {
                automaticMode = false
                automaticRunner.stop("Automático parado.")
                stateMachine.stop()
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                CaptureState.lastHp = null
                CaptureState.lastTargetDetection = TargetDetection(false, 0, 0f, 0f)
                CaptureState.targetProfile = null
                displayedHp = 0
                hpText.text = "HP: --%"
                targetText.text = "Alvo: --"
                stateText.text = "Estado: IDLE"
                status.text = "Captura parada."
            }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            addView(hpText)
            addView(targetText)
            addView(stateText)
            addView(transitionText)
            addView(framesText)
            addView(historyText)
            addView(profileText)
            addView(actionText)
            addView(status)
            addView(startButton)
            addView(hpCalibrationButton)
            addView(targetCalibrationButton)
            addView(settingsButton)
            addView(testTapButton)
            addView(mappingButton)
            addView(stateTestButton)
            addView(sequenceButton)
            addView(startLogicButton)
            addView(automaticStatusText)
            addView(automaticButton)
            addView(pauseButton)
            addView(stopButton)
        }
        setContentView(ScrollView(this).apply { addView(content) })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        config = ConfigStore.load(this)
        applyConfig()
        uiHandler.removeCallbacks(uiUpdater)
        uiHandler.post(uiUpdater)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(uiUpdater)
        automaticRunner.stop("Automático pausado ao sair da tela.")
        super.onPause()
    }

    private fun applyConfig() {
        stateMachine.hpLimit = config.hpLimit
        stateMachine.targetConfidenceLimit = config.targetConfidenceLimit
        stateMachine.requiredTargetFrames = config.targetConfirmFrames
        stateMachine.requiredMissingFrames = config.targetMissingFrames
    }

    private fun updateUi() {
        val measured = CaptureState.lastHp
        if (measured == null) {
            hpText.text = "HP: --%"
        } else {
            val next = when {
                displayedHp == 0 -> measured
                measured < displayedHp - 15 -> measured
                abs(measured - displayedHp) <= 3 -> measured
                else -> ((displayedHp * 0.65f) + (measured * 0.35f)).roundToInt()
            }.coerceIn(0, 100)
            displayedHp = next
            hpText.text = "HP: $displayedHp%"
        }

        val target = CaptureState.lastTargetDetection
        targetText.text = if (CaptureState.targetRegion == null) {
            "Alvo: região não calibrada"
        } else {
            "Alvo: ${if (target.detected) "DETECTADO" else "não detectado"} • confiança ${target.confidence}%"
        }

        // Segurança: HP crítico sempre tem prioridade sobre qualquer perfil em execução.
        val currentHp = CaptureState.lastHp
        val recoveryConfirmed = automaticRunner.updateHpRecovery(
            currentHp,
            config.hpLimit,
            config.hpRecoveryMargin,
            config.hpRecoveryConfirmFrames
        )
        if (automaticRunner.isRunning() && currentHp != null && currentHp <= config.hpLimit) {
            automaticRunner.interruptForSafety(
                "Perfil interrompido: HP crítico (${currentHp}%) ≤ limite (${config.hpLimit}%)."
            )
            stateMachine.emergencyHpCheck(currentHp)
            lastHandledTransitionVersion = stateMachine.transitionVersion() - 1L
        }

        // Durante a recuperação automática, mantém a máquina em CHECK_HP.
        // Só libera o próximo estado depois da confirmação por frames consecutivos.
        if (recoveryConfirmed) {
            stateMachine.resumeAfterHpRecovery()
            lastHandledTransitionVersion = stateMachine.transitionVersion() - 1L
        } else if (!automaticRunner.isHpRecoveryBlocked() &&
            stateMachine.state != AutomationState.IDLE && stateMachine.state != AutomationState.PAUSED) {
            stateMachine.tick(currentHp, target)
        }
        if (automaticMode && stateMachine.transitionVersion() != lastHandledTransitionVersion) {
            lastHandledTransitionVersion = stateMachine.transitionVersion()
            automaticRunner.executeForState(this, stateMachine.state)
        }
        stateText.text = "Estado: ${stateMachine.state.name}"
        transitionText.text = "Motivo: ${stateMachine.transitionDescription()}"
        framesText.text = "Frames positivos: ${stateMachine.positiveFrames()} / ${config.targetConfirmFrames}  |  ausentes: ${stateMachine.missingFrames()} / ${config.targetMissingFrames}"
        val history = stateMachine.history()
        historyText.text = "Histórico de transições:\n" + if (history.isEmpty()) "—" else history.joinToString("\n") { "• $it" }
        val suggestedProfile = StateProfileMappingStore.get(this, stateMachine.state)
        profileText.text = if (suggestedProfile == null) "Perfil sugerido: nenhum" else "Perfil sugerido: $suggestedProfile (modo assistido)"
        actionText.text = "Ação (dry-run): ${stateMachine.lastAction()} | eventos: ${stateMachine.actionCount()}"
        val autoStatus = if (automaticRunner.isRunning()) "EXECUTANDO" else "AGUARDANDO"
        automaticStatusText?.let { it.text = "Automático: $autoStatus" }

        if (CaptureState.hpRegion == null) {
            status.text = "Calibre a barra de HP."
        } else if (CaptureState.targetRegion == null) {
            status.text = "HP calibrado. Calibre a região do alvo."
        }
    }

    private fun startCalibration(target: Boolean) {
        if (CaptureState.lastPreviewFrame == null) {
            status.text = "Inicie a captura e deixe o jogo visível antes de calibrar."
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Permita 'aparecer sobre outros apps' e toque novamente."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        CalibrationOverlayService.start(this, target)
        status.text = if (target) {
            "Ajuste o retângulo sobre o nome/indicador do alvo."
        } else {
            "Ajuste o retângulo sobre a barra de HP."
        }
    }


    private fun showManualTapDialog() {
        if (!AutomationAccessibilityService.isConnected()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            status.text = "Ative o serviço de acessibilidade do HP Detector e tente novamente."
            return
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24, 8, 24, 8)
        }
        val xInput = EditText(this).apply {
            hint = "X"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val yInput = EditText(this).apply {
            hint = "Y"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        container.addView(xInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        container.addView(yInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        AlertDialog.Builder(this)
            .setTitle("Teste manual de toque")
            .setMessage("Informe as coordenadas da tela. O toque será executado uma única vez.")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("TOCAR") { _, _ ->
                val x = xInput.text.toString().toFloatOrNull()
                val y = yInput.text.toString().toFloatOrNull()
                if (x == null || y == null || x < 0 || y < 0) {
                    status.text = "Coordenadas inválidas."
                    return@setPositiveButton
                }
                val accepted = AutomationAccessibilityService.tap(x, y)
                status.text = if (accepted) "Toque enviado manualmente em ($x, $y)." else "Não foi possível enviar o toque."
            }
            .show()
    }

    private fun requestCapture() {
        captureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }
}
