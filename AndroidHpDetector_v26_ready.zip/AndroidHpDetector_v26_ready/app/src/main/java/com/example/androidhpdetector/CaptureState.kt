package com.example.androidhpdetector

import android.graphics.Bitmap

object CaptureState {
    @Volatile var lastHp: Int? = null
    @Volatile var hpRegion: HpRegion? = null
    @Volatile var targetRegion: TargetRegion? = null
    @Volatile var targetProfile: TargetProfile? = null
    @Volatile var lastTargetDetection: TargetDetection = TargetDetection(false, 0, 0f, 0f)
    @Volatile var lastPreviewFrame: Bitmap? = null
}
