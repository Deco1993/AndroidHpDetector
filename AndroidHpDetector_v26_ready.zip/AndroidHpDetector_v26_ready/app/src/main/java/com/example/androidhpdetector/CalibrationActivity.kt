package com.example.androidhpdetector

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CalibrationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Calibrar região do HP"
            textSize = 22f
            setPadding(0, 0, 0, 24)
        }

        fun field(label: String): EditText {
            return EditText(this).apply {
                hint = label
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
        }

        val left = field("X inicial")
        val top = field("Y inicial")
        val right = field("X final")
        val bottom = field("Y final")

        val save = Button(this).apply {
            text = "Salvar região"
            setOnClickListener {
                val l = left.text.toString().toIntOrNull()
                val t = top.text.toString().toIntOrNull()
                val r = right.text.toString().toIntOrNull()
                val b = bottom.text.toString().toIntOrNull()

                if (l != null && t != null && r != null && b != null &&
                    r > l && b > t
                ) {
                    CaptureState.hpRegion = HpRegion(l, t, r, b)
                    finish()
                }
            }
        }

        setContentView(
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(32, 48, 32, 32)
                addView(title)
                addView(left)
                addView(top)
                addView(right)
                addView(bottom)
                addView(save)
            }
        )
    }
}
