package com.example.androidhpdetector

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import kotlin.math.max

class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "screen_capture"
        private const val NOTIFICATION_ID = 1001
        private const val PREVIEW_MAX_WIDTH = 1080
        private const val PREVIEW_INTERVAL_MS = 250L
    }

    private lateinit var projection: MediaProjection
    private lateinit var imageReader: ImageReader
    private var virtualDisplay: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastPreviewTime = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            releaseCapture()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData = intent?.parcelableIntentExtra(EXTRA_RESULT_DATA)

        if (resultCode == -1 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()
        startCapture(resultCode, resultData)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("HP Detector")
            .setContentText("Capturando e analisando a tela…")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val manager = getSystemService(MediaProjectionManager::class.java)
        projection = manager.getMediaProjection(resultCode, resultData)
            ?: run {
                stopSelf()
                return
            }

        projection.registerCallback(projectionCallback, handler)

        imageReader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            2
        )

        imageReader.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener

            try {
                HpDetector.analyze(image, CaptureState.hpRegion) { hp ->
                    CaptureState.lastHp = hp
                }

                val now = System.currentTimeMillis()
                if (now - lastPreviewTime >= PREVIEW_INTERVAL_MS) {
                    lastPreviewTime = now
                    val preview = imageToPreviewBitmap(image)
                    if (preview != null) {
                        CaptureState.lastPreviewFrame = preview
                        CaptureState.lastTargetDetection = TargetDetector.analyze(
                            preview,
                            CaptureState.targetRegion,
                            CaptureState.targetProfile
                        )
                    }
                }
            } finally {
                image.close()
            }
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "HPDetector",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface,
            null,
            handler
        )
    }

    private fun imageToPreviewBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride <= 0 || rowStride <= 0) return null

        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride

        return try {
            buffer.rewind()
            val padded = Bitmap.createBitmap(
                paddedWidth,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(buffer)

            val cropped = if (paddedWidth == image.width) {
                padded
            } else {
                Bitmap.createBitmap(
                    padded,
                    0,
                    0,
                    image.width,
                    image.height
                ).also { padded.recycle() }
            }

            val scale = if (cropped.width > PREVIEW_MAX_WIDTH) {
                PREVIEW_MAX_WIDTH.toFloat() / cropped.width
            } else {
                1f
            }

            if (scale >= 1f) {
                cropped
            } else {
                val previewHeight = max(1, (cropped.height * scale).toInt())
                Bitmap.createScaledBitmap(
                    cropped,
                    PREVIEW_MAX_WIDTH,
                    previewHeight,
                    true
                ).also { cropped.recycle() }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun releaseCapture() {
        virtualDisplay?.release()
        virtualDisplay = null

        if (::imageReader.isInitialized) {
            imageReader.close()
        }
    }

    override fun onDestroy() {
        try {
            if (::projection.isInitialized) {
                projection.unregisterCallback(projectionCallback)
                projection.stop()
            }
        } catch (_: Exception) {
        }

        releaseCapture()
        CaptureState.lastPreviewFrame = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Captura de tela",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }
}

@Suppress("DEPRECATION")
private fun Intent.parcelableIntentExtra(key: String): Intent? {
    return if (Build.VERSION.SDK_INT >= 33) {
        getParcelableExtra(key, Intent::class.java)
    } else {
        getParcelableExtra(key)
    }
}
