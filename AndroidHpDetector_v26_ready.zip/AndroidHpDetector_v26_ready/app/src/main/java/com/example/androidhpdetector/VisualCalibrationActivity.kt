package com.example.androidhpdetector

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class VisualCalibrationActivity : AppCompatActivity() {

    private lateinit var selector: RegionSelectorView
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val frame = CaptureState.lastPreviewFrame
        if (frame == null) {
            showNoFrameMessage()
            return
        }

        selector = RegionSelectorView(this).apply {
            setBitmap(frame)
        }

        info = TextView(this).apply {
            text = "Arraste e redimensione o retângulo sobre a barra de HP."
            textSize = 16f
            setPadding(16, 16, 16, 16)
        }

        val save = Button(this).apply {
            text = "Salvar região"
            setOnClickListener {
                val normalized = selector.getNormalizedSelection()
                val w = frame.width
                val h = frame.height

                CaptureState.hpRegion = HpRegion(
                    (normalized.left * w).roundToInt(),
                    (normalized.top * h).roundToInt(),
                    (normalized.right * w).roundToInt(),
                    (normalized.bottom * h).roundToInt()
                )

                info.text = "Região salva: ${CaptureState.hpRegion}"
            }
        }

        val close = Button(this).apply {
            text = "Voltar"
            setOnClickListener { finish() }
        }

        setContentView(
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 24, 12, 24)
                addView(info)
                addView(
                    selector,
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                    )
                )
                addView(save)
                addView(close)
            }
        )
    }

    private fun showNoFrameMessage() {
        val message = TextView(this).apply {
            text = "Nenhuma prévia disponível.\n\n1. Inicie a captura de tela.\n2. Deixe o jogo visível por alguns segundos.\n3. Volte aqui e abra a calibração novamente."
            textSize = 18f
            setPadding(32, 64, 32, 32)
        }

        val back = Button(this).apply {
            text = "Voltar"
            setOnClickListener { finish() }
        }

        setContentView(
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(message)
                addView(back)
            }
        )
    }
}
