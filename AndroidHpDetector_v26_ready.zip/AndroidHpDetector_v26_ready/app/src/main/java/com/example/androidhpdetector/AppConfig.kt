package com.example.androidhpdetector

import android.content.Context

data class AppConfig(
    val hpLimit: Int = 25,
    val hpRecoveryMargin: Int = 5,
    val hpRecoveryConfirmFrames: Int = 3,
    val targetConfidenceLimit: Int = 55,
    val targetConfirmFrames: Int = 3,
    val targetMissingFrames: Int = 4
)

object ConfigStore {
    private const val PREFS = "automation_config"
    private const val HP_LIMIT = "hp_limit"
    private const val HP_RECOVERY_MARGIN = "hp_recovery_margin"
    private const val HP_RECOVERY_CONFIRM_FRAMES = "hp_recovery_confirm_frames"
    private const val CONFIG_VERSION = "config_version"
    private const val TARGET_CONFIDENCE = "target_confidence"
    private const val TARGET_CONFIRM_FRAMES = "target_confirm_frames"
    private const val TARGET_MISSING_FRAMES = "target_missing_frames"

    fun load(context: Context): AppConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return AppConfig(
            hpLimit = p.getInt(HP_LIMIT, 25).coerceIn(1, 100),
            hpRecoveryMargin = p.getInt(HP_RECOVERY_MARGIN, 5).coerceIn(0, 50),
            hpRecoveryConfirmFrames = p.getInt(HP_RECOVERY_CONFIRM_FRAMES, 3).coerceIn(1, 30),
            targetConfidenceLimit = p.getInt(TARGET_CONFIDENCE, 55).coerceIn(1, 100),
            targetConfirmFrames = p.getInt(TARGET_CONFIRM_FRAMES, 3).coerceIn(1, 30),
            targetMissingFrames = p.getInt(TARGET_MISSING_FRAMES, 4).coerceIn(1, 30)
        )
    }

    fun save(context: Context, config: AppConfig) {
        val safeHpLimit = config.hpLimit.coerceIn(1, 100)
        val safeRecoveryMargin = config.hpRecoveryMargin.coerceIn(0, 50)
        val safeRecoveryFrames = config.hpRecoveryConfirmFrames.coerceIn(1, 30)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(CONFIG_VERSION, 2)
            .putInt(HP_LIMIT, safeHpLimit)
            .putInt(HP_RECOVERY_MARGIN, safeRecoveryMargin)
            .putInt(HP_RECOVERY_CONFIRM_FRAMES, safeRecoveryFrames)
            .putInt(TARGET_CONFIDENCE, config.targetConfidenceLimit.coerceIn(1, 100))
            .putInt(TARGET_CONFIRM_FRAMES, config.targetConfirmFrames.coerceIn(1, 30))
            .putInt(TARGET_MISSING_FRAMES, config.targetMissingFrames.coerceIn(1, 30))
            .apply()
    }
}
