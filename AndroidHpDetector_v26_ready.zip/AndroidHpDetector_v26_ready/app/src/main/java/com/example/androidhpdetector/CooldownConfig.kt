package com.example.androidhpdetector

import android.content.Context

/** Cooldown independente para cada estado que pode disparar um perfil. */
object CooldownConfigStore {
    private const val PREFS = "state_cooldowns"
    private val defaults = mapOf(
        AutomationState.CHECK_HP to 1500L,
        AutomationState.SEARCH_TARGET to 1000L,
        AutomationState.TARGET_FOUND to 1000L,
        AutomationState.ATTACKING to 1500L,
        AutomationState.CHECK_DEATH to 1000L,
        AutomationState.LOOTING to 2000L
    )

    fun load(context: Context, state: AutomationState): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(state.name, defaults[state] ?: 1000L)
            .coerceIn(0L, 60_000L)

    fun save(context: Context, values: Map<AutomationState, Long>) {
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        values.forEach { (state, value) -> editor.putLong(state.name, value.coerceIn(0L, 60_000L)) }
        editor.apply()
    }

    fun defaults(): Map<AutomationState, Long> = defaults
}
