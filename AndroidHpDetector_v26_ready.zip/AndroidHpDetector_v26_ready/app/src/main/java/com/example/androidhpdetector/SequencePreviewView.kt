package com.example.androidhpdetector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

class SequencePreviewView(context: Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 22f }
    private var steps: List<TapStep> = emptyList()
    private var screenWidth = 1f
    private var screenHeight = 1f
    private var currentIndex = -1

    fun setSequence(steps: List<TapStep>, screenWidth: Float, screenHeight: Float, currentIndex: Int = -1) {
        this.steps = steps.toList()
        this.screenWidth = screenWidth.coerceAtLeast(1f)
        this.screenHeight = screenHeight.coerceAtLeast(1f)
        this.currentIndex = currentIndex
        invalidate()
    }

    fun setCurrentIndex(index: Int) {
        currentIndex = index
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), linePaint)
        if (steps.isEmpty()) {
            canvas.drawText("Prévia: nenhum ponto", 20f, 34f, textPaint)
            return
        }

        val sx = width / screenWidth
        val sy = height / screenHeight
        val path = Path()

        steps.forEachIndexed { index, step ->
            val x = (step.x * sx).coerceIn(8f, width - 8f)
            val y = (step.y * sy).coerceIn(8f, height - 8f)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, linePaint)

        steps.forEachIndexed { index, step ->
            val x = (step.x * sx).coerceIn(8f, width - 8f)
            val y = (step.y * sy).coerceIn(8f, height - 8f)
            pointPaint.setARGB(if (index == currentIndex) 255 else 180, 255, 255, 255)
            canvas.drawCircle(x, y, if (index == currentIndex) 12f else 8f, pointPaint)
            canvas.drawText("${index + 1}", x + 10f, y - 10f, textPaint)
        }
    }
}
