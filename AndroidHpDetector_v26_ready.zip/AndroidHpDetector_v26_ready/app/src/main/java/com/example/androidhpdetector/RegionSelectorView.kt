package com.example.androidhpdetector

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class RegionSelectorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bitmap: Bitmap? = null

    private val imageRect = RectF()
    private val selection = RectF(0.20f, 0.10f, 0.80f, 0.16f)

    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        alpha = 80
    }

    private var mode = Mode.NONE
    private var lastX = 0f
    private var lastY = 0f

    private enum class Mode {
        NONE, MOVE, RESIZE_LEFT, RESIZE_RIGHT, RESIZE_TOP, RESIZE_BOTTOM
    }

    fun setBitmap(value: Bitmap) {
        bitmap = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val bmp = bitmap ?: return
        imageRect.set(0f, 0f, width.toFloat(), height.toFloat())

        canvas.drawBitmap(bmp, null, imageRect, imagePaint)

        val rect = selectionInPixels()

        // Escurece tudo fora da seleção.
        canvas.drawRect(0f, 0f, width.toFloat(), rect.top, shadePaint)
        canvas.drawRect(0f, rect.bottom, width.toFloat(), height.toFloat(), shadePaint)
        canvas.drawRect(0f, rect.top, rect.left, rect.bottom, shadePaint)
        canvas.drawRect(rect.right, rect.top, width.toFloat(), rect.bottom, shadePaint)

        canvas.drawRect(rect, borderPaint)
    }

    fun getNormalizedSelection(): RectF = RectF(selection)

    private fun selectionInPixels(): RectF {
        return RectF(
            selection.left * width,
            selection.top * height,
            selection.right * width,
            selection.bottom * height
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y

                val rect = selectionInPixels()
                val edge = 35f

                mode = when {
                    event.x in rect.left - edge..rect.left + edge -> Mode.RESIZE_LEFT
                    event.x in rect.right - edge..rect.right + edge -> Mode.RESIZE_RIGHT
                    event.y in rect.top - edge..rect.top + edge -> Mode.RESIZE_TOP
                    event.y in rect.bottom - edge..rect.bottom + edge -> Mode.RESIZE_BOTTOM
                    rect.contains(event.x, event.y) -> Mode.MOVE
                    else -> Mode.NONE
                }

                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = (event.x - lastX) / width
                val dy = (event.y - lastY) / height

                when (mode) {
                    Mode.MOVE -> {
                        val w = selection.width()
                        val h = selection.height()

                        selection.offset(dx, dy)

                        if (selection.left < 0) selection.offset(-selection.left, 0f)
                        if (selection.top < 0) selection.offset(0f, -selection.top)
                        if (selection.right > 1) selection.offset(1f - selection.right, 0f)
                        if (selection.bottom > 1) selection.offset(0f, 1f - selection.bottom)

                        // Mantém a seleção dentro da imagem.
                        selection.set(
                            selection.left,
                            selection.top,
                            selection.left + w,
                            selection.top + h
                        )
                    }

                    Mode.RESIZE_LEFT -> {
                        selection.left = min(
                            max(0f, selection.left + dx),
                            selection.right - 0.02f
                        )
                    }

                    Mode.RESIZE_RIGHT -> {
                        selection.right = max(
                            min(1f, selection.right + dx),
                            selection.left + 0.02f
                        )
                    }

                    Mode.RESIZE_TOP -> {
                        selection.top = min(
                            max(0f, selection.top + dy),
                            selection.bottom - 0.02f
                        )
                    }

                    Mode.RESIZE_BOTTOM -> {
                        selection.bottom = max(
                            min(1f, selection.bottom + dy),
                            selection.top + 0.02f
                        )
                    }

                    Mode.NONE -> Unit
                }

                lastX = event.x
                lastY = event.y
                invalidate()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = Mode.NONE
                return true
            }
        }

        return true
    }
}
