package com.example.androidhpdetector

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StateProfileMappingActivity : AppCompatActivity() {
    private lateinit var container: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 40, 32, 32) }
        root.addView(TextView(this).apply { text = "Perfis por estado (modo assistido)"; textSize = 24f })
        root.addView(TextView(this).apply {
            text = "Associe um perfil a cada estado. Nesta versão a máquina apenas sugere o perfil; nenhuma sequência é executada automaticamente."
            textSize = 15f; setPadding(0, 12, 0, 20)
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 16) }
        root.addView(status)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(container)
        root.addView(Button(this).apply { text = "Voltar"; setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun render() {
        container.removeAllViews()
        val profiles = SequenceProfileStore.list(this)
        val states = listOf(
            AutomationState.CHECK_HP,
            AutomationState.SEARCH_TARGET,
            AutomationState.TARGET_FOUND,
            AutomationState.ATTACKING,
            AutomationState.CHECK_DEATH,
            AutomationState.LOOTING
        )
        if (profiles.isEmpty()) {
            status.text = "Crie pelo menos um perfil em 'Perfis de sequência' primeiro."
        } else {
            status.text = "Perfil sugerido: nenhum estado executa automaticamente."
        }
        states.forEach { state ->
            val label = TextView(this).apply { text = state.name; textSize = 17f; setPadding(0, 12, 0, 4) }
            val spinner = Spinner(this)
            val options = listOf("Nenhum") + profiles
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            val current = StateProfileMappingStore.get(this, state)
            spinner.setSelection(options.indexOf(current).coerceAtLeast(0))
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val selected = options[position].takeUnless { it == "Nenhum" }
                    StateProfileMappingStore.set(this@StateProfileMappingActivity, state, selected)
                }
            }
            container.addView(label)
            container.addView(spinner)
        }
    }
}
