package com.example.androidhpdetector

import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SequenceProfilesActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply { text = "Escolha um perfil para carregar, ou salve a sequência atual com um novo nome."; textSize = 15f; setPadding(0, 12, 0, 16) }

        val save = Button(this).apply { text = "Salvar sequência atual como perfil"; setOnClickListener { askName() } }
        val back = Button(this).apply { text = "Voltar"; setOnClickListener { finish() } }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 40, 32, 32)
            addView(TextView(this@SequenceProfilesActivity).apply { text = "Perfis de sequência"; textSize = 24f })
            addView(status); addView(save); addView(list); addView(back)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun askName() {
        val input = EditText(this).apply { hint = "Nome do perfil"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        AlertDialog.Builder(this).setTitle("Salvar perfil").setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank()) { status.text = "Informe um nome."; return@setPositiveButton }
                val saved = ManualSequenceStore.load(this)
                SequenceProfileStore.save(this, SequenceProfile(name, saved.first, saved.second))
                status.text = "Perfil '$name' salvo com ${saved.first.size} passo(s)."
                render()
            }.show()
    }

    private fun render() {
        list.removeAllViews()
        val names = SequenceProfileStore.list(this)
        if (names.isEmpty()) {
            list.addView(TextView(this).apply { text = "Nenhum perfil salvo."; setPadding(0, 16, 0, 16) })
            return
        }
        names.forEach { name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
            val load = Button(this).apply {
                text = name; setOnClickListener {
                    val profile = SequenceProfileStore.load(this@SequenceProfilesActivity, name)
                    if (profile != null) {
                        ManualSequenceStore.save(this@SequenceProfilesActivity, profile.steps, profile.repeatCount)
                        status.text = "Perfil '$name' carregado."
                    }
                }
            }
            val delete = Button(this).apply { text = "Excluir"; setOnClickListener {
                AlertDialog.Builder(this@SequenceProfilesActivity).setTitle("Excluir perfil?").setMessage(name)
                    .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ -> SequenceProfileStore.delete(this@SequenceProfilesActivity, name); render() }.show()
            } }
            row.addView(load, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); row.addView(delete)
            list.addView(row)
        }
    }
}
