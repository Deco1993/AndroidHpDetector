package com.example.androidhpdetector

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ManualSequenceActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val steps = mutableListOf<TapStep>()
    private var repeatCount = 1
    private var running = false
    private var paused = false
    private var currentIndex = 0
    private var currentRound = 1

    private lateinit var listText: TextView
    private lateinit var statusText: TextView
    private lateinit var repeatInput: EditText
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var preview: SequencePreviewView

    private val tapRunnable = object : Runnable {
        override fun run() {
            if (!running || paused) return
            if (steps.isEmpty()) return stopSequence("Nenhum passo configurado.")

            val step = steps[currentIndex]
            val accepted = AutomationAccessibilityService.tap(step.x, step.y)
            statusText.text = "${if (accepted) "Toque enviado" else "Falha ao enviar toque"}: rodada $currentRound/$repeatCount • passo ${currentIndex + 1}/${steps.size} (${step.x}, ${step.y})"
            preview.setCurrentIndex(currentIndex)

            val delay = step.intervalAfterMs
            currentIndex++
            if (currentIndex >= steps.size) {
                if (currentRound >= repeatCount) {
                    stopSequence("Sequência concluída.")
                    return
                }
                currentRound++
                currentIndex = 0
            }
            if (running) handler.postDelayed(this, delay)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = ManualSequenceStore.load(this)
        steps.addAll(saved.first)
        repeatCount = saved.second

        listText = TextView(this).apply { textSize = 16f; setPadding(8, 8, 8, 16) }
        statusText = TextView(this).apply { text = "Parado."; textSize = 15f; setPadding(8, 8, 8, 16) }
        repeatInput = EditText(this).apply {
            hint = "Repetições (1 = uma vez)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(repeatCount.toString())
        }

        val addButton = Button(this).apply {
            text = "Adicionar toque"
            setOnClickListener { showStepDialog(null, -1) }
        }
        val clearButton = Button(this).apply {
            text = "Limpar sequência"
            setOnClickListener {
                stopSequence("Sequência limpa.")
                steps.clear()
                renderSteps()
                save()
            }
        }
        val saveButton = Button(this).apply {
            text = "Salvar configuração"
            setOnClickListener {
                readRepeat()
                save()
                statusText.text = "Configuração salva."
            }
        }
        val profilesButton = Button(this).apply {
            text = "Perfis de sequência"
            setOnClickListener { startActivity(Intent(this@ManualSequenceActivity, SequenceProfilesActivity::class.java)) }
        }

        pauseButton = Button(this).apply {
            text = "Pausar"
            isEnabled = false
            setOnClickListener {
                if (!running) return@setOnClickListener
                if (paused) resumeSequence() else pauseSequence()
            }
        }
        startButton = Button(this).apply {
            text = "Iniciar sequência"
            setOnClickListener { if (running) stopSequence("Sequência parada.") else startSequence() }
        }
        val backButton = Button(this).apply {
            text = "Voltar"
            setOnClickListener { finish() }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 32)
            addView(TextView(this@ManualSequenceActivity).apply { text = "Modo manual — sequência de toques"; textSize = 22f })
            addView(TextView(this@ManualSequenceActivity).apply {
                text = "Cada passo tem seu próprio intervalo após o toque. Toque em um item para editar ou remover."
                textSize = 15f; setPadding(0, 12, 0, 16)
            })
            addView(listText)
            preview = SequencePreviewView(this@ManualSequenceActivity).apply {
                setSequence(steps, resources.displayMetrics.widthPixels.toFloat(), resources.displayMetrics.heightPixels.toFloat())
            }
            addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 420))
            addView(repeatInput)
            addView(addButton)
            addView(clearButton)
            addView(saveButton)
            addView(profilesButton)
            addView(startButton)
            addView(pauseButton)
            addView(statusText)
            addView(backButton)
        }
        setContentView(ScrollView(this).apply { addView(content) })
        renderSteps()
    }

    private fun showStepDialog(existing: TapStep?, index: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 8) }
        val x = EditText(this).apply {
            hint = "X"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(existing?.x?.toString() ?: "")
        }
        val y = EditText(this).apply {
            hint = "Y"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(existing?.y?.toString() ?: "")
        }
        val interval = EditText(this).apply {
            hint = "Intervalo após este toque (ms)"; inputType = InputType.TYPE_CLASS_NUMBER
            setText((existing?.intervalAfterMs ?: 500L).toString())
        }
        row.addView(x); row.addView(y); row.addView(interval)

        val builder = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Adicionar ponto" else "Editar ponto")
            .setMessage("O intervalo define quanto esperar antes do próximo toque.")
            .setView(row)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton(if (existing == null) "Adicionar" else "Salvar") { _, _ ->
                val px = x.text.toString().toFloatOrNull()
                val py = y.text.toString().toFloatOrNull()
                val wait = (interval.text.toString().toLongOrNull() ?: 500L).coerceIn(50L, 60_000L)
                if (px == null || py == null || px < 0f || py < 0f) {
                    statusText.text = "Coordenadas inválidas."
                    return@setPositiveButton
                }
                val step = TapStep(px, py, wait)
                if (index >= 0) steps[index] = step else steps.add(step)
                renderSteps(); save()
                statusText.text = if (index >= 0) "Passo #${index + 1} atualizado." else "Passo #${steps.size} adicionado."
            }
        if (existing != null) {
            builder.setNeutralButton("Remover") { _, _ ->
                if (index in steps.indices) {
                    steps.removeAt(index); renderSteps(); save(); statusText.text = "Passo removido."
                }
            }
        }
        builder.show()
    }

    private fun startSequence() {
        if (!AutomationAccessibilityService.isConnected()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            statusText.text = "Ative o serviço de acessibilidade e tente novamente."
            return
        }
        if (steps.isEmpty()) {
            statusText.text = "Adicione pelo menos um ponto."
            return
        }
        readRepeat(); save()
        running = true; paused = false; currentIndex = 0; currentRound = 1
        startButton.text = "Parar sequência"
        pauseButton.isEnabled = true
        pauseButton.text = "Pausar"
        statusText.text = "Sequência iniciada: $repeatCount repetição(ões)."
        handler.removeCallbacks(tapRunnable)
        handler.post(tapRunnable)
    }

    private fun stopSequence(message: String = "Sequência parada.") {
        running = false
        paused = false
        handler.removeCallbacks(tapRunnable)
        startButton.text = "Iniciar sequência"
        pauseButton.isEnabled = false
        pauseButton.text = "Pausar"
        preview.setCurrentIndex(-1)
        statusText.text = message
    }

    private fun pauseSequence() {
        paused = true
        handler.removeCallbacks(tapRunnable)
        pauseButton.text = "Retomar"
        statusText.text = "Pausado: rodada $currentRound/$repeatCount • passo ${currentIndex + 1}/${steps.size}."
    }

    private fun resumeSequence() {
        if (!running) return
        paused = false
        pauseButton.text = "Pausar"
        statusText.text = "Retomando: rodada $currentRound/$repeatCount • passo ${currentIndex + 1}/${steps.size}."
        handler.removeCallbacks(tapRunnable)
        handler.post(tapRunnable)
    }

    private fun readRepeat() {
        repeatCount = (repeatInput.text.toString().toIntOrNull() ?: 1).coerceIn(1, 999)
        repeatInput.setText(repeatCount.toString())
    }

    private fun save() = ManualSequenceStore.save(this, steps, repeatCount)

    private fun renderSteps() {
        listText.text = if (steps.isEmpty()) {
            "Nenhum ponto configurado."
        } else {
            steps.mapIndexed { index, step ->
                "${index + 1}. X=${step.x}  Y=${step.y}  → ${step.intervalAfterMs} ms"
            }.joinToString("\n")
        }
        listText.setOnClickListener {
            if (steps.isEmpty()) return@setOnClickListener
            // O texto inteiro não oferece seleção individual; o editor detalhado abaixo é aberto pelo botão.
        }
        // Botões de edição são adicionados via diálogo quando o usuário toca na lista através de um menu.
        listText.contentDescription = "Toque longo para editar um passo"
        if (::preview.isInitialized) preview.setSequence(steps, resources.displayMetrics.widthPixels.toFloat(), resources.displayMetrics.heightPixels.toFloat(), if (running) currentIndex else -1)
        listText.setOnLongClickListener {
            showStepPicker(); true
        }
    }

    private fun showStepPicker() {
        if (steps.isEmpty()) return
        val labels = steps.mapIndexed { i, s -> "${i + 1}. X=${s.x}, Y=${s.y}, ${s.intervalAfterMs} ms" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Editar passo")
            .setItems(labels) { _, which -> showStepDialog(steps[which], which) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        val saved = ManualSequenceStore.load(this)
        steps.clear(); steps.addAll(saved.first); repeatCount = saved.second
        if (::repeatInput.isInitialized) repeatInput.setText(repeatCount.toString())
        if (::listText.isInitialized) renderSteps()
    }

    override fun onDestroy() {
        stopSequence()
        super.onDestroy()
    }
}
