package com.example.androidhpdetector

import android.media.Image
import kotlin.math.roundToInt

object HpDetector {

    /**
     * Estima o preenchimento horizontal da barra dentro da ROI calibrada.
     * Usa uma classificação de vermelho baseada em saturação/contraste,
     * tolerando pequenas mudanças de brilho.
     */
    fun analyze(image: Image, region: HpRegion?, callback: (Int) -> Unit) {
        if (region == null) {
            callback(0)
            return
        }

        val plane = image.planes.firstOrNull() ?: run {
            callback(0)
            return
        }
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride <= 0 || rowStride <= 0) {
            callback(0)
            return
        }

        val left = region.left.coerceIn(0, image.width - 1)
        val right = region.right.coerceIn(left + 1, image.width)
        val top = region.top.coerceIn(0, image.height - 1)
        val bottom = region.bottom.coerceIn(top + 1, image.height)

        val stepX = maxOf(2, (right - left) / 120)
        val stepY = maxOf(2, (bottom - top) / 12)

        var totalColumns = 0
        var filledColumns = 0

        for (x in left until right step stepX) {
            var redSamples = 0
            var samples = 0

            for (y in top until bottom step stepY) {
                val index = y * rowStride + x * pixelStride
                if (index < 0 || index + 2 >= buffer.limit()) continue

                val r = buffer.get(index).toInt() and 0xFF
                val g = buffer.get(index + 1).toInt() and 0xFF
                val b = buffer.get(index + 2).toInt() and 0xFF

                samples++
                if (isHpRed(r, g, b)) redSamples++
            }

            if (samples > 0) {
                totalColumns++
                if (redSamples.toFloat() / samples >= 0.30f) {
                    filledColumns++
                }
            }
        }

        val hp = if (totalColumns == 0) 0 else
            ((filledColumns.toFloat() / totalColumns) * 100f)
                .roundToInt()
                .coerceIn(0, 100)

        callback(hp)
    }

    private fun isHpRed(r: Int, g: Int, b: Int): Boolean {
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val saturation = if (max == 0) 0f else (max - min).toFloat() / max

        // Vermelho precisa dominar os outros canais, mas não exige um
        // valor RGB absoluto alto para funcionar em cenas mais escuras.
        return r >= 80 &&
                r - g >= 28 &&
                r - b >= 28 &&
                saturation >= 0.28f
    }
}
