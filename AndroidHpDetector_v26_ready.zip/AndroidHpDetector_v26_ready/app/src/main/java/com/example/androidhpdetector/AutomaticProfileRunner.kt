package com.example.androidhpdetector

import android.os.Handler
import android.os.Looper

/** Executa o perfil associado ao estado atual quando o modo automático está explicitamente ativo. */
class AutomaticProfileRunner(private val onStatus: (String) -> Unit) {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var index = 0
    private var round = 1
    private var profile: SequenceProfile? = null
    private var context: android.content.Context? = null
    private val lastExecutionAt = mutableMapOf<AutomationState, Long>()
    private var activeState: AutomationState? = null
    /** Após uma interrupção por HP baixo, impede a retomada de perfis de combate até o HP recuperar. */
    private var hpRecoveryBlocked = false
    private var hpRecoveryConfirmCount = 0

    private val task = object : Runnable {
        override fun run() {
            if (!running) return
            val p = profile ?: return stop("Nenhum perfil associado.")
            if (index !in p.steps.indices) return stop("Perfil concluído.")
            val step = p.steps[index]
            val ok = AutomationAccessibilityService.tap(step.x, step.y)
            onStatus("Automático: ${if (ok) "toque enviado" else "falha no toque"} • ${p.name} • ${round}/${p.repeatCount} • passo ${index + 1}/${p.steps.size}")
            index++
            if (index >= p.steps.size) {
                if (round >= p.repeatCount) return stop("Automático: perfil concluído.")
                round++
                index = 0
            }
            handler.postDelayed(this, step.intervalAfterMs)
        }
    }

    fun executeForState(context: android.content.Context, state: AutomationState) {
        // CHECK_HP continua permitido para executar o perfil de emergência.
        // Os demais perfis ficam bloqueados até o HP voltar acima do limite.
        if (hpRecoveryBlocked && state != AutomationState.CHECK_HP) {
            onStatus("Automático bloqueado: aguardando recuperação de HP acima do limite antes de retomar ${state.name}.")
            return
        }
        if (running) {
            onStatus("Automático bloqueado: reentrada em ${state.name}; perfil atual ainda está em execução.")
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val cooldownMs = CooldownConfigStore.load(context, state)
        val last = lastExecutionAt[state]
        if (last != null) {
            val elapsed = now - last
            if (elapsed < cooldownMs) {
                val remaining = cooldownMs - elapsed
                onStatus("Automático bloqueado por cooldown em ${state.name}: ${remaining} ms restantes.")
                return
            }
        }
        val name = StateProfileMappingStore.get(context, state)
        val loaded = name?.let { SequenceProfileStore.load(context, it) }
        if (loaded == null || loaded.steps.isEmpty()) {
            onStatus("Automático: nenhum perfil para ${state.name}.")
            return
        }
        if (!AutomationAccessibilityService.isConnected()) {
            onStatus("Automático: acessibilidade não está ativa.")
            return
        }
        this.context = context.applicationContext
        profile = loaded
        index = 0
        round = 1
        running = true
        activeState = state
        onStatus("Automático: iniciando ${loaded.name} para ${state.name} • cooldown após conclusão ${cooldownMs} ms")
        handler.post(task)
    }

    /** Interrompe a execução quando uma condição externa de segurança é detectada. */
    fun interruptForSafety(message: String): AutomationState? {
        if (!running) return null
        val interruptedState = activeState
        hpRecoveryBlocked = true
        hpRecoveryConfirmCount = 0
        stop(message)
        return interruptedState
    }

    /** Libera a retomada somente quando o HP estiver estritamente acima do limite. */
    fun updateHpRecovery(currentHp: Int?, hpLimit: Int, recoveryMargin: Int, requiredFrames: Int): Boolean {
        if (!hpRecoveryBlocked || currentHp == null) return false
        val recoveryThreshold = (hpLimit + recoveryMargin.coerceIn(0, 50)).coerceAtMost(100)
        val required = requiredFrames.coerceIn(1, 30)
        if (currentHp >= recoveryThreshold) {
            hpRecoveryConfirmCount++
            onStatus("Recuperação de HP: ${hpRecoveryConfirmCount}/${required} frames (${currentHp}% >= ${recoveryThreshold}%).")
            if (hpRecoveryConfirmCount >= required) {
                hpRecoveryBlocked = false
                hpRecoveryConfirmCount = 0
                onStatus("Recuperação de HP confirmada. Automação liberada.")
                return true
            }
        } else {
            if (hpRecoveryConfirmCount > 0) {
                onStatus("Confirmação de recuperação reiniciada: HP ${currentHp}% abaixo de ${recoveryThreshold}%.")
            }
            hpRecoveryConfirmCount = 0
        }
        return false
    }

    fun hpRecoveryConfirmCount(): Int = hpRecoveryConfirmCount

    fun isHpRecoveryBlocked(): Boolean = hpRecoveryBlocked

    fun stop(message: String? = "Automático: parado.") {
        val finishedState = activeState
        running = false
        handler.removeCallbacks(task)
        profile = null
        index = 0
        round = 1
        activeState = null
        if (finishedState != null) {
            lastExecutionAt[finishedState] = android.os.SystemClock.elapsedRealtime()
        }
        message?.let(onStatus)
    }

    fun isRunning(): Boolean = running
}
