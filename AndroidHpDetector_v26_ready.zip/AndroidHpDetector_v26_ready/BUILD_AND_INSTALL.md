# AndroidHpDetector v26 — build e instalação

Este pacote contém o código-fonte da v26.

## Requisitos
- Android Studio recente
- Android SDK Platform 35
- JDK compatível com a versão do Android Studio/Gradle

## Gerar APK de teste
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Execute **Build > Build APK(s)**.
4. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

O projeto usa `compileSdk 35`, `targetSdk 35` e `minSdk 26`, portanto o Galaxy S21 FE atende ao mínimo de API.

## Instalar no S21 FE
Copie o APK para o celular, abra pelo app Meus Arquivos e toque em Instalar. Se o Android solicitar, permita temporariamente a instalação de fontes desconhecidas para o aplicativo que abriu o APK.

Depois da instalação, abra o app e conceda somente as permissões necessárias às funções que você pretende testar, como captura de tela, sobreposição e acessibilidade.

O projeto não contém mecanismos para ocultar automação ou contornar sistemas anti-cheat.
