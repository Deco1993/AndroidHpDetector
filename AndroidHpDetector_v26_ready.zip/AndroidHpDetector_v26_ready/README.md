# AndroidHpDetector

Protótipo Android em Kotlin para captura de tela, detecção visual de HP/alvo, máquina de estados, diagnóstico e interação manual por acessibilidade.

## Modo manual de sequência
A versão atual inclui uma tela para configurar uma sequência de toques:
- adicionar vários pontos X/Y;
- definir intervalo entre toques (50 ms a 60 s);
- salvar a configuração no aparelho;
- iniciar e parar manualmente;
- acompanhar qual toque foi enviado por último.

A sequência é deliberadamente independente da máquina de estados: ela não é disparada automaticamente pelo detector.

## Observação
O serviço de acessibilidade precisa ser ativado manualmente nas configurações do Android. O projeto não implementa mecanismos para ocultar automação ou contornar sistemas anti-cheat.

## v16 — Perfis de sequência
- Salve várias sequências manuais com nomes diferentes.
- Carregue um perfil para substituir a sequência atual.
- Exclua perfis que não forem mais necessários.
- Os perfis ficam persistidos localmente no aparelho.

## v17 — Perfis por estado (modo assistido)
- Associa perfis de sequência aos estados CHECK_HP, SEARCH_TARGET, TARGET_FOUND, ATTACKING, CHECK_DEATH e LOOTING.
- A tela principal mostra o perfil sugerido para o estado atual.
- Nenhum perfil é executado automaticamente nesta versão.
- A associação fica salva no aparelho.

## v18 — teste manual de perfil por estado

- Novo botão `Testar perfil por estado (manual)` na tela principal.
- Permite selecionar um estado e carregar o perfil associado.
- Mostra a sequência completa antes da execução.
- Exige confirmação explícita antes de iniciar.
- Execução pode ser interrompida pelo botão `Parar`.
- Continua separada da máquina de estados: nenhuma execução automática é feita por transições.

## v19 — modo automático controlado
- Modo automático desligado por padrão.
- Confirmação explícita antes de ativar.
- Ao entrar em um estado, o perfil associado pode ser executado pelo `AutomaticProfileRunner`.
- O botão de parada interrompe a execução.
- Acessibilidade precisa estar ativa.
- Não inclui mecanismos de ocultação ou evasão de anti-cheat.


## v21 — interrupção por HP crítico

Quando o modo automático está executando um perfil e o HP capturado fica menor ou igual ao limite configurado, o perfil é interrompido imediatamente e a máquina retorna para `CHECK_HP`. A ocorrência aparece no diagnóstico. A proteção é prioritária sobre o perfil atual.

## v22 — trava de recuperação de HP

Após uma interrupção por HP crítico, a automação entra em uma trava de recuperação:
- perfis de combate/fluxo ficam bloqueados enquanto o HP permanecer menor ou igual ao limite;
- o estado `CHECK_HP` continua liberado para executar o perfil de emergência configurado;
- a trava só é liberada quando o HP ficar estritamente acima do limite;
- ao recuperar o HP, o fluxo normal da máquina de estados pode retomar os perfis associados aos próximos estados;
- o restante do comportamento da v21, incluindo cooldown, proteção contra reentrada e interrupção por HP crítico, permanece igual.

## v23 — Histerese de recuperação de HP
- Mantém a trava de recuperação introduzida na v22.
- Adiciona margem de recuperação de HP configurável.
- Padrão: limite de 25% + margem de 5% = liberação em 30%.
- Enquanto bloqueado, perfis diferentes de CHECK_HP continuam impedidos.
- A liberação ocorre quando HP >= limite + margem.
- Margem configurável de 0% a 50%.


## v24 — persistência das configurações de HP
- O limite de HP e a margem de recuperação são armazenados em `SharedPreferences` no aparelho.
- Os valores são restaurados ao abrir/reabrir a tela principal e permanecem após encerrar o aplicativo.
- Ao salvar as configurações, os valores são validados e persistidos junto com a versão do esquema de configuração.
- Alterar configurações em `Configurar parâmetros` passa a ser refletido novamente ao retornar à tela principal.
- O restante do comportamento da v23, incluindo histerese, trava de recuperação, cooldown e interrupção por HP crítico, permanece igual.


## v26 — retomada determinística após recuperação
- A máquina permanece em `CHECK_HP` enquanto a trava de recuperação estiver ativa.
- A retomada exige o número configurado de frames consecutivos acima do limiar de recuperação.
- Quando a recuperação é confirmada, a máquina transita explicitamente para `SEARCH_TARGET`.
- A nova transição garante que o perfil de `SEARCH_TARGET` seja processado pelo modo automático sem depender de uma mudança acidental de estado.
- Mantém histerese, persistência, cooldown, proteção contra reentrada e interrupção de segurança.

### Fluxo final
`HP <= limite` → interrompe perfil → `CHECK_HP` → aguarda recuperação → confirma N frames → `SEARCH_TARGET` → fluxo normal.
